M2_SOURCE is not an iWidget!

It is merely a folder to hold resources for other M2 iWidgets.

None of these resources need to be modified- all the slideshow slides are located in the slideshow directory.