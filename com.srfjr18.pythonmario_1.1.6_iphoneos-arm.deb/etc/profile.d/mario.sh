if [[ $(activator current-app) == "com.srfjr18.mario" ]] ; then
/usr/bin/mario.py ; fi